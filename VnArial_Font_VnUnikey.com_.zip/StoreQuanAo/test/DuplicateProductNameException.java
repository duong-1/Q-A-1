public class DuplicateProductNameException extends Exception {
    public DuplicateProductNameException(String message) {
        super(message);
    }
}
