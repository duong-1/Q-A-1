/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author TB
 */
public class DonHangSanPhamHoanChinh {

    private int SanPhamId;
    private String PhanLoai;
    private String TenSanPham;
    private String KichThuoc;
    private String mausac;
    private String chatlieu;
    private int HoaDonId;
    private boolean TrangThaiDonHang;
    private String NguoiDungId;
    private int ChiTietSanPhamId;
    private String PhuongThucThanhToan;
    private String HoTenKhachHang;
    private String SoDienThoai;
    private String ThuocTinhSanPhamId;
    private float giaTien;
    private int soLuong;
    private int SoLuongSanPhamGoc;
    private int SanPhamSanPhamChiTietId;

    public int getSanPhamSanPhamChiTietId() {
        return SanPhamSanPhamChiTietId;
    }

    public void setSanPhamSanPhamChiTietId(int SanPhamSanPhamChiTietId) {
        this.SanPhamSanPhamChiTietId = SanPhamSanPhamChiTietId;
    }

    public int getSoLuongSanPhamGoc() {
        return SoLuongSanPhamGoc;
    }

    public void setSoLuongSanPhamGoc(int SoLuongSanPhamGoc) {
        this.SoLuongSanPhamGoc = SoLuongSanPhamGoc;
    }

    public String getPhuongThucThanhToan() {
        return PhuongThucThanhToan;
    }

    public void setPhuongThucThanhToan(String PhuongThucThanhToan) {
        this.PhuongThucThanhToan = PhuongThucThanhToan;
    }

    public String getHoTenKhachHang() {
        return HoTenKhachHang;
    }

    public void setHoTenKhachHang(String HoTenKhachHang) {
        this.HoTenKhachHang = HoTenKhachHang;
    }

    public String getSoDienThoai() {
        return SoDienThoai;
    }

    public void setSoDienThoai(String SoDienThoai) {
        this.SoDienThoai = SoDienThoai;
    }
    
    

    public String getKichThuoc() {
        return KichThuoc;
    }

    public void setKichThuoc(String KichThuoc) {
        this.KichThuoc = KichThuoc;
    }
 

    public int getSanPhamId() {
        return SanPhamId;
    }

    public void setSanPhamId(int SanPhamId) {
        this.SanPhamId = SanPhamId;
    }

    public String getPhanLoai() {
        return PhanLoai;
    }

    public void setPhanLoai(String PhanLoai) {
        this.PhanLoai = PhanLoai;
    }

    public String getTenSanPham() {
        return TenSanPham;
    }

    public void setTenSanPham(String TenSanPham) {
        this.TenSanPham = TenSanPham;
    }

    public int getHoaDonId() {
        return HoaDonId;
    }

    public void setHoaDonId(int HoaDonId) {
        this.HoaDonId = HoaDonId;
    }

    public String getMausac() {
        return mausac;
    }

    public void setMausac(String mausac) {
        this.mausac = mausac;
    }

    public String getChatlieu() {
        return chatlieu;
    }

    public void setChatlieu(String chatlieu) {
        this.chatlieu = chatlieu;
    }



  
    public String getNguoiDungId() {
        return NguoiDungId;
    }

    public void setNguoiDungId(String NguoiDungId) {
        this.NguoiDungId = NguoiDungId;
    }

    public int getChiTietSanPhamId() {
        return ChiTietSanPhamId;
    }

    public void setChiTietSanPhamId(int ChiTietSanPhamId) {
        this.ChiTietSanPhamId = ChiTietSanPhamId;
    }

    

    public String getThuocTinhSanPhamId() {
        return ThuocTinhSanPhamId;
    }

    public void setThuocTinhSanPhamId(String ThuocTinhSanPhamId) {
        this.ThuocTinhSanPhamId = ThuocTinhSanPhamId;
    }

    public float getGiaTien() {
        return giaTien;
    }

    public void setGiaTien(float giaTien) {
        this.giaTien = giaTien;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public boolean isTrangThaiDonHang() {
        return TrangThaiDonHang;
    }

    public void setTrangThaiDonHang(boolean TrangThaiDonHang) {
        this.TrangThaiDonHang = TrangThaiDonHang;
    }

    public DonHangSanPhamHoanChinh() {
    }

//    public DonHangSanPhamHoanChinh(int SanPhamId, String PhanLoai, String TenSanPham, String KichThuoc, String mausac, String chatlieu, int HoaDonId, boolean TrangThaiDonHang, String NguoiDungId, int ChiTietSanPhamId, String ThuocTinhSanPhamId, float giaTien, int soLuong, int SanPhamSanPhamChiTietId) {
//        this.SanPhamId = SanPhamId;
//        this.PhanLoai = PhanLoai;
//        this.TenSanPham = TenSanPham;
//        this.KichThuoc = KichThuoc;
//        this.mausac = mausac;
//        this.chatlieu = chatlieu;
//        this.HoaDonId = HoaDonId;
//        this.TrangThaiDonHang = TrangThaiDonHang;
//        this.NguoiDungId = NguoiDungId;
//        this.ChiTietSanPhamId = ChiTietSanPhamId;
//        this.ThuocTinhSanPhamId = ThuocTinhSanPhamId;
//        this.giaTien = giaTien;
//        this.soLuong = soLuong;
//        this.SanPhamSanPhamChiTietId = SanPhamSanPhamChiTietId;
//    }

    public DonHangSanPhamHoanChinh(int SanPhamId, String PhanLoai, String TenSanPham, String KichThuoc, String mausac, String chatlieu, int HoaDonId, boolean TrangThaiDonHang, String NguoiDungId, int ChiTietSanPhamId, String PhuongThucThanhToan, String HoTenKhachHang, String SoDienThoai, String ThuocTinhSanPhamId, float giaTien, int soLuong, int SanPhamSanPhamChiTietId,int SoLuongSanPhamGoc) {
        this.SanPhamId = SanPhamId;
        this.PhanLoai = PhanLoai;
        this.TenSanPham = TenSanPham;
        this.KichThuoc = KichThuoc;
        this.mausac = mausac;
        this.chatlieu = chatlieu;
        this.HoaDonId = HoaDonId;
        this.TrangThaiDonHang = TrangThaiDonHang;
        this.NguoiDungId = NguoiDungId;
        this.ChiTietSanPhamId = ChiTietSanPhamId;
        this.PhuongThucThanhToan = PhuongThucThanhToan;
        this.HoTenKhachHang = HoTenKhachHang;
        this.SoDienThoai = SoDienThoai;
        this.ThuocTinhSanPhamId = ThuocTinhSanPhamId;
        this.giaTien = giaTien;
        this.soLuong = soLuong;
        this.SanPhamSanPhamChiTietId = SanPhamSanPhamChiTietId;
        this.SoLuongSanPhamGoc = SoLuongSanPhamGoc;
    }

    
  


    
    
}
